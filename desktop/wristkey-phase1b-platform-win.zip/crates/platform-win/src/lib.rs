use wristkey_core::vault::{DeviceVault, KeyProtector};
use wristkey_core::{PlatformSecurity, WristKeyError, Result, SessionManager};
use wristkey_crypto::generate_key;
use std::sync::Arc;
use windows::Win32::Security::Cryptography::{
    CryptProtectData, CryptUnprotectData, CRYPT_INTEGER_BLOB,
};
use windows::Win32::Foundation::{HLOCAL, LocalFree};

/// Windows DPAPI protector for the 32-byte pairingKey.
pub struct WindowsKeyProtector;

impl KeyProtector for WindowsKeyProtector {
    fn protect(&self, plaintext: &[u8]) -> Vec<u8> {
        unsafe {
            let mut data_in = CRYPT_INTEGER_BLOB {
                cbData: plaintext.len() as u32,
                pbData: plaintext.as_ptr() as *mut u8,
            };
            let mut data_out = CRYPT_INTEGER_BLOB::default();
            CryptProtectData(&mut data_in, None, None, None, None, 0, &mut data_out)
                .expect("CryptProtectData failed");
            let slice = std::slice::from_raw_parts(data_out.pbData, data_out.cbData as usize);
            let result = slice.to_vec();
            let _ = LocalFree(HLOCAL(data_out.pbData as *mut std::ffi::c_void));
            result
        }
    }

    fn unprotect(&self, ciphertext: &[u8]) -> Option<Vec<u8>> {
        unsafe {
            let mut data_in = CRYPT_INTEGER_BLOB {
                cbData: ciphertext.len() as u32,
                pbData: ciphertext.as_ptr() as *mut u8,
            };
            let mut data_out = CRYPT_INTEGER_BLOB::default();
            CryptUnprotectData(&mut data_in, None, None, None, None, 0, &mut data_out).ok()?;
            let slice = std::slice::from_raw_parts(data_out.pbData, data_out.cbData as usize);
            let result = slice.to_vec();
            let _ = LocalFree(HLOCAL(data_out.pbData as *mut std::ffi::c_void));
            Some(result)
        }
    }
}

/// High-level vault — same interface as before, but uses DeviceVault internally.
pub struct WindowsVault {
    vault: DeviceVault<WindowsKeyProtector>,
}

impl WindowsVault {
    pub fn new() -> Self {
        let home = std::env::var("USERPROFILE")
            .or_else(|_| std::env::var("HOME"))
            .unwrap_or_else(|_| ".".to_string());
        let path = std::path::PathBuf::from(home).join(".wristkey/devices.json");
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        Self {
            vault: DeviceVault::new(path, WindowsKeyProtector),
        }
    }

    pub fn store_password(&self, device_id: &str, password: &str) -> std::result::Result<(), String> {
        let pairing_key = generate_key();
        self.vault
            .add_device(
                device_id.to_string(),
                "WristKey Device".to_string(),
                std::env::var("USERNAME").unwrap_or_else(|_| "user".to_string()),
                password,
                &pairing_key,
                "".to_string(),
            )
            .map_err(|e| e.to_string())
    }

    pub fn retrieve_password(&self, device_id: &str) -> std::result::Result<String, String> {
        self.vault
            .get_device_password(device_id)
            .map_err(|e| e.to_string())
    }

    /// Async encrypt password (backward-compat for main.rs).
    pub async fn encrypt_password(&self, password: &str) -> std::result::Result<Vec<u8>, String> {
        // For now: store and return dummy encrypted blob (main.rs uses this for CP pipe)
        let pairing_key = generate_key();
        let encrypted = wristkey_crypto::encrypt(password.as_bytes(), &pairing_key);
        Ok(encrypted)
    }
}

/// Platform security adapter for Windows.
pub struct WindowsSecurity {
    session: Option<Arc<SessionManager>>,
}

impl WindowsSecurity {
    pub fn new() -> Self {
        Self { session: None }
    }

    pub fn set_session(&mut self, session: Arc<SessionManager>) {
        self.session = Some(session);
    }

    /// Lazy pipe server — starts on first unlock request from CP.
    pub fn start_pipe_server() {
        // TODO: implement named pipe server when CP integration is needed
    }

    pub fn is_credential_provider_registered() -> bool {
        // TODO: check registry
        false
    }

    pub fn storage_type_description() -> &'static str {
        "DPAPI (Windows Data Protection)"
    }

    pub async fn ensure_dll_extracted() -> std::result::Result<std::path::PathBuf, String> {
        // TODO: extract embedded DLL
        Err("DLL extraction not yet implemented".to_string())
    }

    pub fn register_credential_provider(_dll_path: &str) -> std::result::Result<(), String> {
        // TODO: registry manipulation
        Ok(())
    }

    pub fn unregister_credential_provider() -> std::result::Result<(), String> {
        // TODO: registry cleanup
        Ok(())
    }
}

#[async_trait::async_trait]
impl PlatformSecurity for WindowsSecurity {
    async fn lock_screen(&self) -> Result<()> {
        unsafe {
            windows::Win32::System::Shutdown::LockWorkStation();
        }
        Ok(())
    }

    async fn unlock_screen(&self) -> Result<()> {
        Ok(())
    }

    async fn is_locked(&self) -> Result<bool> {
        Ok(false)
    }

    async fn register_as_authenticator(&self) -> Result<()> {
        Ok(())
    }
}
