# WristKey

Open-source PC unlock via Wear OS smartwatch using BLE and ECDSA challenge-response.

## Structure

- `desktop/` — Rust workspace (daemon + platform adapters)
- `wear-os/` — Android (Kotlin) companion app
- `proto/` — Formal protocol specification

## Quick Start

```bash
cd desktop
cargo build --workspace --features linux   # or windows / macos
```

## Protocol

See [PROTOCOL.md](desktop/proto/PROTOCOL.md).
