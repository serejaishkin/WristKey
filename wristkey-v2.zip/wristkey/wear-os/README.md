# WristKey Wear OS

Android companion app (Kotlin + Compose for Wear OS).

## Structure (to be implemented)

- `app/` — Foreground Service + BLE Peripheral
- `security/` — Android Keystore ECDSA P-256 operations
- `sensors/` — Accelerometer / motion detection

## Protocol

Implements BLE GATT server with challenge-response signing.
See `../desktop/proto/PROTOCOL.md`.
