# WristKey Protocol Specification v1.0.0

## Overview

Challenge-response over BLE GATT. LE Secure Connections (Mode 1 Level 4) required.

## GATT Service

- **Service UUID:** `a1b2c3d4-e5f6-7890-abcd-ef1234567890` (placeholder)
- **Characteristics:**
  - `CHALLENGE` (UUID `...01`) — write, PC → Watch
  - `RESPONSE` (UUID `...02`) — notify, Watch → PC
  - `STATUS` (UUID `...03`) — read/notify, connection health

## Challenge-Response Flow

1. PC generates 16-byte nonce, writes to `CHALLENGE`
2. Watch signs nonce + timestamp (8 bytes LE) + user-present flag (1 byte)
3. Watch notifies 64-byte Ed25519 signature on `RESPONSE`
4. PC verifies signature against paired public key

## Auto-Lock

- RSSI sampled every 2s
- Exponential moving average with α = 0.3
- If RSSI < threshold for 30s → `PlatformSecurity::lock_screen()`

## Pairing

1. PC enters pairing mode (30s window)
2. Watch advertises with pairing flag
3. LE Secure Connections pairing via OS
4. Key exchange: Watch sends Ed25519 public key (32 bytes)
5. PC stores key in encrypted storage
