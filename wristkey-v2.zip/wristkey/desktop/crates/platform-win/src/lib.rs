//! Windows platform adapter.
//!
//! Implements screen lock via `LockWorkStation`.
//! Unlock via Windows Hello CDF is planned for v2 (MVP = lock only).

use async_trait::async_trait;
use tracing::{info, warn};
use wristkey_core::{PlatformSecurity, Result, WristKeyError};

pub struct WindowsSecurity;

impl WindowsSecurity {
    pub fn new() -> Self {
        Self
    }
}

#[async_trait]
impl PlatformSecurity for WindowsSecurity {
    async fn lock_screen(&self) -> Result<()> {
        #[cfg(windows)]
        {
            use windows::Win32::System::WindowsProgramming::LockWorkStation;
            // SAFETY: LockWorkStation has no arguments and is safe to call.
            unsafe {
                LockWorkStation().map_err(|e| {
                    WristKeyError::Platform(format!("LockWorkStation failed: {:?}", e))
                })?;
            }
            info!("workstation locked via WinAPI");
            Ok(())
        }
        #[cfg(not(windows))]
        {
            warn!("WindowsSecurity::lock_screen called on non-Windows platform");
            Err(WristKeyError::Platform("not on Windows".into()))
        }
    }

    async fn is_locked(&self) -> Result<bool> {
        // TODO: detect lock screen state via WTSQuerySessionInformation or checking foreground window
        warn!("is_locked not yet implemented on Windows");
        Ok(false)
    }

    async fn register_as_authenticator(&self) -> Result<()> {
        // TODO: register Credential Provider V2 for Windows Hello integration
        warn!("register_as_authenticator not yet implemented on Windows");
        Ok(())
    }
}
