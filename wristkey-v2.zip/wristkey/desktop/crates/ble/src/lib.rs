//! BLE abstraction layer over `btleplug`.
//!
//! Provides async traits for scanning, connecting, and communicating with Wear OS peripherals.

use async_trait::async_trait;
use btleplug::api::{Central, CentralEvent, Manager as _, Peripheral as _, ScanFilter};
use btleplug::platform::{Adapter, Manager, Peripheral};
use tokio::sync::mpsc;
use tracing::{debug, error, info, warn};
use uuid::Uuid;
use wristkey_core::{Result, WristKeyError};

// =============================================================================
// Data types
// =============================================================================

/// Information about a discovered peripheral.
#[derive(Clone, Debug)]
pub struct PeripheralInfo {
    pub id: Uuid,
    pub name: Option<String>,
    pub rssi: Option<i16>,
    pub service_uuids: Vec<Uuid>,
}

/// Handle to an active BLE connection.
#[derive(Clone, Debug)]
pub struct Connection {
    pub peripheral_id: Uuid,
    pub device_name: String,
}

// =============================================================================
// BLE Adapter Trait
// =============================================================================

#[async_trait]
pub trait BleAdapter: Send + Sync {
    /// Start scanning for peripherals advertising the given service UUID.
    async fn scan(&self, service_uuid: Uuid) -> Result<mpsc::Receiver<PeripheralInfo>>;

    /// Connect to a discovered peripheral.
    async fn connect(&self, info: &PeripheralInfo) -> Result<Connection>;

    /// Disconnect and clean up.
    async fn disconnect(&self, conn: &Connection) -> Result<()>;

    /// Write data to a GATT characteristic.
    async fn write(&self, conn: &Connection, characteristic: Uuid, data: &[u8]) -> Result<()>;

    /// Subscribe to notifications from a characteristic.
    async fn notify(&self, conn: &Connection, characteristic: Uuid) -> Result<mpsc::Receiver<Vec<u8>>>;

    /// Read current RSSI (if supported by platform).
    async fn read_rssi(&self, conn: &Connection) -> Result<i16>;
}

// =============================================================================
// btleplug Implementation
// =============================================================================

pub struct BtleplugAdapter {
    manager: Manager,
    adapter: Adapter,
}

impl BtleplugAdapter {
    pub async fn new() -> Result<Self> {
        let manager = Manager::new().await.map_err(|e| {
            WristKeyError::Ble(format!("failed to create BLE manager: {}", e))
        })?;
        let adapters = manager.adapters().await.map_err(|e| {
            WristKeyError::Ble(format!("failed to list adapters: {}", e))
        })?;
        let adapter = adapters.into_iter().next().ok_or_else(|| {
            WristKeyError::Ble("no BLE adapter found".into())
        })?;
        info!("using BLE adapter: {:?}", adapter.adapter_info().await);
        Ok(Self { manager, adapter })
    }
}

#[async_trait]
impl BleAdapter for BtleplugAdapter {
    async fn scan(&self, service_uuid: Uuid) -> Result<mpsc::Receiver<PeripheralInfo>> {
        let (tx, rx) = mpsc::channel(32);
        let filter = ScanFilter {
            services: vec![service_uuid],
        };

        self.adapter
            .start_scan(filter)
            .await
            .map_err(|e| WristKeyError::Ble(format!("scan failed: {}", e)))?;

        // Spawn event processing task
        let adapter = self.adapter.clone();
        tokio::spawn(async move {
            // In real impl, listen to CentralEvent::DeviceDiscovered
            // and resolve peripheral info.
            todo!("implement BLE event loop for device discovery")
        });

        Ok(rx)
    }

    async fn connect(&self, info: &PeripheralInfo) -> Result<Connection> {
        debug!("connecting to {}", info.id);
        // Resolve peripheral by UUID, connect, discover services.
        todo!("implement btleplug connection logic")
    }

    async fn disconnect(&self, conn: &Connection) -> Result<()> {
        debug!("disconnecting from {}", conn.peripheral_id);
        todo!("implement btleplug disconnect")
    }

    async fn write(&self, conn: &Connection, characteristic: Uuid, data: &[u8]) -> Result<()> {
        debug!(
            "writing {} bytes to {} on {}",
            data.len(),
            characteristic,
            conn.peripheral_id
        );
        todo!("implement GATT write")
    }

    async fn notify(&self, conn: &Connection, characteristic: Uuid) -> Result<mpsc::Receiver<Vec<u8>>> {
        debug!("subscribing to notifications on {}", characteristic);
        todo!("implement GATT notify subscription")
    }

    async fn read_rssi(&self, conn: &Connection) -> Result<i16> {
        debug!("reading RSSI for {}", conn.peripheral_id);
        // btleplug does not expose RSSI directly on all platforms;
        // may need platform-specific extension.
        todo!("implement RSSI reading")
    }
}

// =============================================================================
// Mock Implementation (for unit tests without hardware)
// =============================================================================

pub struct MockBleAdapter {
    scripted_responses: std::sync::Mutex<Vec<Vec<u8>>>,
}

impl MockBleAdapter {
    pub fn new() -> Self {
        Self {
            scripted_responses: std::sync::Mutex::new(Vec::new()),
        }
    }

    pub fn queue_response(&self, data: Vec<u8>) {
        self.scripted_responses.lock().unwrap().push(data);
    }
}

#[async_trait]
impl BleAdapter for MockBleAdapter {
    async fn scan(&self, _service_uuid: Uuid) -> Result<mpsc::Receiver<PeripheralInfo>> {
        let (tx, rx) = mpsc::channel(4);
        tx.send(PeripheralInfo {
            id: Uuid::new_v4(),
            name: Some("Mock Watch".into()),
            rssi: Some(-45),
            service_uuids: vec![_service_uuid],
        })
        .await
        .map_err(|e| WristKeyError::Ble(e.to_string()))?;
        Ok(rx)
    }

    async fn connect(&self, info: &PeripheralInfo) -> Result<Connection> {
        Ok(Connection {
            peripheral_id: info.id,
            device_name: info.name.clone().unwrap_or_else(|| "unknown".into()),
        })
    }

    async fn disconnect(&self, _conn: &Connection) -> Result<()> {
        Ok(())
    }

    async fn write(&self, _conn: &Connection, _characteristic: Uuid, _data: &[u8]) -> Result<()> {
        Ok(())
    }

    async fn notify(&self, _conn: &Connection, _characteristic: Uuid) -> Result<mpsc::Receiver<Vec<u8>>> {
        let (tx, rx) = mpsc::channel(4);
        if let Some(data) = self.scripted_responses.lock().unwrap().pop() {
            let _ = tx.send(data).await;
        }
        Ok(rx)
    }

    async fn read_rssi(&self, _conn: &Connection) -> Result<i16> {
        Ok(-50)
    }
}
