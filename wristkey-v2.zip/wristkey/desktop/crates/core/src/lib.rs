//! WristKey core: state machine, crypto traits, and challenge-response logic.
//!
//! This crate is platform-agnostic and contains all business logic.

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use rand::RngCore;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use thiserror::Error;
use tokio::sync::RwLock;
use tracing::{debug, error, info, warn};
use uuid::Uuid;

// =============================================================================
// Errors
// =============================================================================

#[derive(Error, Debug)]
pub enum WristKeyError {
    #[error("crypto operation failed: {0}")]
    Crypto(String),

    #[error("invalid signature")]
    InvalidSignature,

    #[error("session error: {0}")]
    Session(String),

    #[error("storage error: {0}")]
    Storage(String),

    #[error("protocol error: {0}")]
    Protocol(String),

    #[error("platform error: {0}")]
    Platform(String),

    #[error("ble error: {0}")]
    Ble(String),
}

pub type Result<T> = std::result::Result<T, WristKeyError>;

// =============================================================================
// Crypto Engine Trait
// =============================================================================

/// Abstracts all cryptographic operations.
/// Production impl uses Android Keystore (Wear OS) or ed25519-dalek (desktop).
#[async_trait]
pub trait CryptoEngine: Send + Sync {
    /// Generate a new Ed25519 keypair.
    async fn generate_keypair(&self) -> Result<(Vec<u8>, Vec<u8>)>;

    /// Sign data with the private key.
    async fn sign(&self, private_key: &[u8], data: &[u8]) -> Result<Vec<u8>>;

    /// Verify signature with the public key.
    async fn verify(&self, public_key: &[u8], data: &[u8], signature: &[u8]) -> Result<()>;
}

/// Default software-based crypto engine (desktop fallback).
pub struct SoftwareCrypto;

#[async_trait]
impl CryptoEngine for SoftwareCrypto {
    async fn generate_keypair(&self) -> Result<(Vec<u8>, Vec<u8>)> {
        let mut rng = rand::thread_rng();
        let signing_key = SigningKey::generate(&mut rng);
        let verifying_key = signing_key.verifying_key();
        Ok((signing_key.to_bytes().to_vec(), verifying_key.to_bytes().to_vec()))
    }

    async fn sign(&self, private_key: &[u8], data: &[u8]) -> Result<Vec<u8>> {
        let key_bytes: [u8; 32] = private_key
            .try_into()
            .map_err(|_| WristKeyError::Crypto("invalid private key length".into()))?;
        let signing_key = SigningKey::from_bytes(&key_bytes);
        let signature = signing_key.sign(data);
        Ok(signature.to_bytes().to_vec())
    }

    async fn verify(&self, public_key: &[u8], data: &[u8], signature: &[u8]) -> Result<()> {
        let key_bytes: [u8; 32] = public_key
            .try_into()
            .map_err(|_| WristKeyError::Crypto("invalid public key length".into()))?;
        let verifying_key = VerifyingKey::from_bytes(&key_bytes)
            .map_err(|e| WristKeyError::Crypto(e.to_string()))?;
        let sig_bytes: [u8; 64] = signature
            .try_into()
            .map_err(|_| WristKeyError::Crypto("invalid signature length".into()))?;
        let sig = Signature::from_bytes(&sig_bytes);
        verifying_key
            .verify(data, &sig)
            .map_err(|_| WristKeyError::InvalidSignature)
    }
}

// =============================================================================
// Storage Trait
// =============================================================================

/// Persistent storage for paired devices and configuration.
#[async_trait]
pub trait Storage: Send + Sync {
    async fn save_device(&self, device: &PairedDevice) -> Result<()>;
    async fn load_device(&self, id: Uuid) -> Result<Option<PairedDevice>>;
    async fn list_devices(&self) -> Result<Vec<PairedDevice>>;
    async fn delete_device(&self, id: Uuid) -> Result<()>;
    async fn load_config(&self) -> Result<Config>;
    async fn save_config(&self, config: &Config) -> Result<()>;
}

/// In-memory storage for testing.
pub struct MemoryStorage {
    devices: Arc<RwLock<HashMap<Uuid, PairedDevice>>>,
    config: Arc<RwLock<Config>>,
}

impl MemoryStorage {
    pub fn new() -> Self {
        Self {
            devices: Arc::new(RwLock::new(HashMap::new())),
            config: Arc::new(RwLock::new(Config::default())),
        }
    }
}

#[async_trait]
impl Storage for MemoryStorage {
    async fn save_device(&self, device: &PairedDevice) -> Result<()> {
        self.devices.write().await.insert(device.id, device.clone());
        info!("saved device {}", device.id);
        Ok(())
    }

    async fn load_device(&self, id: Uuid) -> Result<Option<PairedDevice>> {
        Ok(self.devices.read().await.get(&id).cloned())
    }

    async fn list_devices(&self) -> Result<Vec<PairedDevice>> {
        Ok(self.devices.read().await.values().cloned().collect())
    }

    async fn delete_device(&self, id: Uuid) -> Result<()> {
        self.devices.write().await.remove(&id);
        info!("deleted device {}", id);
        Ok(())
    }

    async fn load_config(&self) -> Result<Config> {
        Ok(self.config.read().await.clone())
    }

    async fn save_config(&self, config: &Config) -> Result<()> {
        *self.config.write().await = config.clone();
        Ok(())
    }
}

// =============================================================================
// Data Models
// =============================================================================

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PairedDevice {
    pub id: Uuid,
    pub name: String,
    pub public_key: Vec<u8>,
    pub paired_at: DateTime<Utc>,
    /// Baseline RSSI measured during pairing
    pub baseline_rssi: i16,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Config {
    pub auto_lock_timeout_sec: u64,
    pub rssi_threshold_offset_dbm: i16,
    pub challenge_timeout_sec: u64,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            auto_lock_timeout_sec: 30,
            rssi_threshold_offset_dbm: 15,
            challenge_timeout_sec: 10,
        }
    }
}

/// Challenge payload sent to the watch.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Challenge {
    pub nonce: [u8; 16],
    pub issued_at: DateTime<Utc>,
}

impl Challenge {
    pub fn generate() -> Self {
        let mut nonce = [0u8; 16];
        rand::thread_rng().fill_bytes(&mut nonce);
        Self {
            nonce,
            issued_at: Utc::now(),
        }
    }

    /// Serialize to bytes for signing/verification.
    pub fn to_bytes(&self) -> Vec<u8> {
        // Simple concatenation: nonce || issued_at timestamp (8 bytes LE)
        let mut buf = self.nonce.to_vec();
        let ts = self.issued_at.timestamp() as u64;
        buf.extend_from_slice(&ts.to_le_bytes());
        buf
    }
}

/// Response from the watch includes signature and metadata.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Response {
    pub signature: Vec<u8>,
    pub user_present: bool,
    pub timestamp: DateTime<Utc>,
}

// =============================================================================
// Platform Security Trait
// =============================================================================

/// OS-specific screen lock/unlock operations.
#[async_trait]
pub trait PlatformSecurity: Send + Sync {
    /// Lock the workstation immediately.
    async fn lock_screen(&self) -> Result<()>;

    /// Check if the session is currently locked.
    async fn is_locked(&self) -> Result<bool>;

    /// Register this authenticator with the OS (Windows Hello / PAM / etc).
    async fn register_as_authenticator(&self) -> Result<()>;
}

// =============================================================================
// Session State Machine
// =============================================================================

/// Typed state machine for a BLE session.
/// Transitions are enforced by the type system (sealed pattern).
#[derive(Clone, Debug)]
pub enum SessionState {
    Disconnected,
    Pairing {
        challenge: Challenge,
        started_at: DateTime<Utc>,
    },
    Authenticated {
        device_id: Uuid,
        last_rssi: i16,
        last_seen: DateTime<Utc>,
    },
    Locked,
}

impl SessionState {
    pub fn is_authenticated(&self) -> bool {
        matches!(self, SessionState::Authenticated { .. })
    }

    pub fn device_id(&self) -> Option<Uuid> {
        match self {
            SessionState::Authenticated { device_id, .. } => Some(*device_id),
            _ => None,
        }
    }
}

/// Manages session lifecycle and challenge-response verification.
pub struct SessionManager {
    crypto: Arc<dyn CryptoEngine>,
    storage: Arc<dyn Storage>,
    state: Arc<RwLock<SessionState>>,
}

impl SessionManager {
    pub fn new(crypto: Arc<dyn CryptoEngine>, storage: Arc<dyn Storage>) -> Self {
        Self {
            crypto,
            storage,
            state: Arc::new(RwLock::new(SessionState::Disconnected)),
        }
    }

    pub async fn state(&self) -> SessionState {
        self.state.read().await.clone()
    }

    /// Initiate pairing: generate challenge and transition to Pairing state.
    pub async fn begin_pairing(&self) -> Result<Challenge> {
        let challenge = Challenge::generate();
        let new_state = SessionState::Pairing {
            challenge: challenge.clone(),
            started_at: Utc::now(),
        };
        *self.state.write().await = new_state;
        info!("pairing started, nonce={:?}", challenge.nonce);
        Ok(challenge)
    }

    /// Verify response during pairing and store device if valid.
    pub async fn complete_pairing(
        &self,
        device_name: String,
        public_key: Vec<u8>,
        response: &Response,
        baseline_rssi: i16,
    ) -> Result<PairedDevice> {
        let state = self.state.read().await.clone();
        let challenge = match state {
            SessionState::Pairing { challenge, .. } => challenge,
            other => {
                return Err(WristKeyError::Session(format!(
                    "expected Pairing state, got {:?}",
                    other
                )))
            }
        };

        // Verify signature
        let challenge_bytes = challenge.to_bytes();
        self.crypto
            .verify(&public_key, &challenge_bytes, &response.signature)
            .await?;

        if !response.user_present {
            warn!("pairing response missing user-present flag");
            return Err(WristKeyError::Protocol(
                "user presence required for pairing".into(),
            ));
        }

        let device = PairedDevice {
            id: Uuid::new_v4(),
            name: device_name,
            public_key,
            paired_at: Utc::now(),
            baseline_rssi,
        };

        self.storage.save_device(&device).await?;
        *self.state.write().await = SessionState::Authenticated {
            device_id: device.id,
            last_rssi: baseline_rssi,
            last_seen: Utc::now(),
        };

        info!("pairing completed for device {}", device.id);
        Ok(device)
    }

    /// Verify unlock response from a previously paired device.
    pub async fn verify_unlock(&self, device_id: Uuid, response: &Response) -> Result<()> {
        let device = self
            .storage
            .load_device(device_id)
            .await?
            .ok_or_else(|| WristKeyError::Storage("device not found".into()))?;

        // In real flow, challenge is retrieved from current session state
        let challenge = Challenge::generate(); // placeholder: should come from BLE write
        let challenge_bytes = challenge.to_bytes();

        self.crypto
            .verify(&device.public_key, &challenge_bytes, &response.signature)
            .await?;

        if !response.user_present {
            return Err(WristKeyError::Protocol(
                "user presence required for unlock".into(),
            ));
        }

        *self.state.write().await = SessionState::Authenticated {
            device_id,
            last_rssi: device.baseline_rssi,
            last_seen: Utc::now(),
        };

        info!("unlock verified for device {}", device_id);
        Ok(())
    }

    /// Update RSSI and check auto-lock condition.
    pub async fn update_rssi(&self, rssi: i16) -> Result<bool> {
        let mut state = self.state.write().await;
        match *state {
            SessionState::Authenticated {
                ref mut last_rssi,
                ref mut last_seen,
                device_id,
            } => {
                *last_rssi = rssi;
                *last_seen = Utc::now();

                let config = self.storage.load_config().await?;
                let device = self
                    .storage
                    .load_device(device_id)
                    .await?
                    .ok_or_else(|| WristKeyError::Storage("device missing".into()))?;

                let threshold = device.baseline_rssi - config.rssi_threshold_offset_dbm;
                let should_lock = rssi < threshold;

                debug!(
                    "rssi={}, threshold={}, should_lock={}",
                    rssi, threshold, should_lock
                );
                Ok(should_lock)
            }
            _ => Ok(false),
        }
    }

    pub async fn disconnect(&self) {
        *self.state.write().await = SessionState::Disconnected;
        info!("session disconnected");
    }
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_challenge_generation() {
        let c1 = Challenge::generate();
        let c2 = Challenge::generate();
        assert_ne!(c1.nonce, c2.nonce);
    }

    #[tokio::test]
    async fn test_full_pairing_flow() {
        let crypto = Arc::new(SoftwareCrypto);
        let storage = Arc::new(MemoryStorage::new());
        let manager = SessionManager::new(crypto.clone(), storage);

        let challenge = manager.begin_pairing().await.unwrap();
        let (priv_key, pub_key) = crypto.generate_keypair().await.unwrap();
        let sig = crypto.sign(&priv_key, &challenge.to_bytes()).await.unwrap();

        let response = Response {
            signature: sig,
            user_present: true,
            timestamp: Utc::now(),
        };

        let device = manager
            .complete_pairing("Test Watch".into(), pub_key, &response, -50)
            .await
            .unwrap();

        assert_eq!(device.name, "Test Watch");
        assert!(manager.state().await.is_authenticated());
    }

    #[tokio::test]
    async fn test_unlock_without_user_present_fails() {
        let crypto = Arc::new(SoftwareCrypto);
        let storage = Arc::new(MemoryStorage::new());
        let manager = SessionManager::new(crypto.clone(), storage.clone());

        // Pair first
        let challenge = manager.begin_pairing().await.unwrap();
        let (priv_key, pub_key) = crypto.generate_keypair().await.unwrap();
        let sig = crypto.sign(&priv_key, &challenge.to_bytes()).await.unwrap();
        let response = Response {
            signature: sig,
            user_present: true,
            timestamp: Utc::now(),
        };
        let device = manager
            .complete_pairing("Watch".into(), pub_key.clone(), &response, -50)
            .await
            .unwrap();

        // Try unlock without user_present
        let bad_response = Response {
            signature: sig,
            user_present: false,
            timestamp: Utc::now(),
        };
        let result = manager.verify_unlock(device.id, &bad_response).await;
        assert!(result.is_err());
    }
}
