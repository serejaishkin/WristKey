//! macOS platform adapter.
//!
//! - Screen lock via `CGSession` / `SACLockScreenImmediate` (private API).
//! - NO Apple Watch emulation — patent trap.
//! - Unlock is intentionally NOT implemented via Accessibility API (fragile).
//!   MVP: presence detection prevents auto-lock; user unlocks manually.

use async_trait::async_trait;
use tracing::{info, warn};
use wristkey_core::{PlatformSecurity, Result, WristKeyError};

pub struct MacOSSecurity;

impl MacOSSecurity {
    pub fn new() -> Self {
        Self
    }
}

#[async_trait]
impl PlatformSecurity for MacOSSecurity {
    async fn lock_screen(&self) -> Result<()> {
        #[cfg(target_os = "macos")]
        {
            // Use AppleScript to trigger lock screen (reliable across macOS versions).
            // Alternative: `SACLockScreenImmediate` from private SecurityAgent framework.
            let script = r#"tell application "System Events" to keystroke "q" using {command down, control down}"#;
            let output = std::process::Command::new("osascript")
                .arg("-e")
                .arg(script)
                .output()
                .map_err(|e| WristKeyError::Platform(format!("osascript failed: {}", e)))?;

            if !output.status.success() {
                let stderr = String::from_utf8_lossy(&output.stderr);
                return Err(WristKeyError::Platform(format!(
                    "macOS lock failed: {}",
                    stderr
                )));
            }

            info!("screen locked via AppleScript");
            Ok(())
        }
        #[cfg(not(target_os = "macos"))]
        {
            warn!("MacOSSecurity::lock_screen called on non-macOS platform");
            Err(WristKeyError::Platform("not on macOS".into()))
        }
    }

    async fn is_locked(&self) -> Result<bool> {
        // Check CGSession copy for OnConsole key.
        // TODO: implement via CoreGraphics or IOKit.
        warn!("is_locked not yet implemented on macOS");
        Ok(false)
    }

    async fn register_as_authenticator(&self) -> Result<()> {
        // macOS does not have a pluggable auth framework like PAM for GUI login.
        // We rely on presence detection only.
        info!("macOS authenticator: presence detection mode");
        Ok(())
    }
}
