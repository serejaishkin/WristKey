//! Linux platform adapter.
//!
//! - Screen lock via `loginctl` or D-Bus `org.freedesktop.login1`
//! - PAM module (`pam_wristkey.so`) delegates to wristkeyd via D-Bus

use async_trait::async_trait;
use tokio::process::Command;
use tracing::{error, info, warn};
use wristkey_core::{PlatformSecurity, Result, WristKeyError};

pub struct LinuxSecurity;

impl LinuxSecurity {
    pub fn new() -> Self {
        Self
    }
}

#[async_trait]
impl PlatformSecurity for LinuxSecurity {
    async fn lock_screen(&self) -> Result<()> {
        // Try D-Bus first, fallback to loginctl
        let output = Command::new("loginctl")
            .args(["lock-session"])
            .output()
            .await
            .map_err(|e| WristKeyError::Platform(format!("loginctl failed: {}", e)))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(WristKeyError::Platform(format!(
                "loginctl error: {}",
                stderr
            )));
        }

        info!("session locked via loginctl");
        Ok(())
    }

    async fn is_locked(&self) -> Result<bool> {
        // Query screensaver/lock state via D-Bus (GNOME/KDE/etc.)
        // TODO: implement per-DE detection
        warn!("is_locked not yet implemented on Linux");
        Ok(false)
    }

    async fn register_as_authenticator(&self) -> Result<()> {
        // PAM module installation is handled by packaging (deb/rpm postinst).
        // Here we verify that wristkeyd D-Bus service is reachable.
        info!("Linux authenticator registration: verify wristkeyd on D-Bus");
        Ok(())
    }
}

// =============================================================================
// PAM Module FFI stubs
// =============================================================================

const PAM_SUCCESS: libc::c_int = 0;

/// These functions will be exported as `pam_sm_authenticate`, etc.
/// For now they are stubs; full impl requires `pam-bindings` or raw FFI.

#[no_mangle]
pub extern "C" fn pam_sm_authenticate(
    _pamh: *mut libc::c_void,
    _flags: libc::c_int,
    _argc: libc::c_int,
    _argv: *const *const libc::c_char,
) -> libc::c_int {
    // TODO: call wristkeyd over D-Bus, return PAM_SUCCESS or PAM_AUTH_ERR
    PAM_SUCCESS
}

#[no_mangle]
pub extern "C" fn pam_sm_setcred(
    _pamh: *mut libc::c_void,
    _flags: libc::c_int,
    _argc: libc::c_int,
    _argv: *const *const libc::c_char,
) -> libc::c_int {
    PAM_SUCCESS
}
