//! WristKey daemon — entry point.
//!
//! Responsibilities:
//! 1. Initialize platform security adapter (compile-time selected via cfg).
//! 2. Spawn BLE scanning + RSSI monitoring loop.
//! 3. Run GUI tray (future: `tray-icon` + `winit`).
//! 4. Handle pairing and unlock flows via `SessionManager`.

use std::sync::Arc;
use tokio::time::{interval, Duration};
use tracing::{debug, error, info, warn};
use wristkey_core::{Config, CryptoEngine, MemoryStorage, SessionManager, SoftwareCrypto, Storage};
use wristkey_ble::{BleAdapter, BtleplugAdapter};

// Platform-specific imports
#[cfg(all(feature = "windows", target_os = "windows"))]
use wristkey_platform_win::WindowsSecurity;
#[cfg(all(feature = "linux", target_os = "linux"))]
use wristkey_platform_linux::LinuxSecurity;
#[cfg(all(feature = "macos", target_os = "macos"))]
use wristkey_platform_macos::MacOSSecurity;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Initialize logging
    tracing_subscriber::fmt::init();
    info!("WristKey daemon starting");

    // Core services
    let crypto: Arc<dyn CryptoEngine> = Arc::new(SoftwareCrypto);
    let storage: Arc<dyn Storage> = Arc::new(MemoryStorage::new());
    let session = SessionManager::new(crypto.clone(), storage.clone());

    // Ensure default config exists
    if storage.load_config().await.is_err() {
        let _ = storage.save_config(&Config::default()).await;
    }

    // Platform security adapter
    let platform = create_platform_adapter();
    info!("platform adapter initialized");

    // BLE adapter (btleplug)
    let ble = BtleplugAdapter::new().await?;
    info!("BLE adapter initialized");

    // Main event loop
    let mut tick = interval(Duration::from_secs(2));
    loop {
        tick.tick().await;

        match session.state().await {
            wristkey_core::SessionState::Disconnected => {
                // TODO: start scanning for known devices
                debug!("state: disconnected, scanning...");
            }
            wristkey_core::SessionState::Authenticated { device_id, last_rssi, last_seen } => {
                // TODO: read RSSI, call session.update_rssi(), auto-lock if needed
                debug!(
                    "state: authenticated device={} rssi={} last_seen={}",
                    device_id, last_rssi, last_seen
                );
            }
            other => {
                debug!("state: {:?}", other);
            }
        }
    }
}

/// Factory for platform-specific security adapter.
fn create_platform_adapter() -> Arc<dyn wristkey_core::PlatformSecurity> {
    #[cfg(all(feature = "windows", target_os = "windows"))]
    {
        Arc::new(WindowsSecurity::new())
    }
    #[cfg(all(feature = "linux", target_os = "linux"))]
    {
        Arc::new(LinuxSecurity::new())
    }
    #[cfg(all(feature = "macos", target_os = "macos"))]
    {
        Arc::new(MacOSSecurity::new())
    }
    #[cfg(not(any(
        all(feature = "windows", target_os = "windows"),
        all(feature = "linux", target_os = "linux"),
        all(feature = "macos", target_os = "macos"),
    )))]
    {
        compile_error!("enable exactly one platform feature: windows, linux, or macos")
    }
}
